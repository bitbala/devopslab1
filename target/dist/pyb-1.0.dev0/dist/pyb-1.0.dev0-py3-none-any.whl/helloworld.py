def helloworld(out):
    out.write("Hello World!!!")
